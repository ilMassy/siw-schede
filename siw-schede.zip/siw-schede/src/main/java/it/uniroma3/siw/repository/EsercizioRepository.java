package it.uniroma3.siw.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import it.uniroma3.siw.model.Esercizio;
import it.uniroma3.siw.model.Prestazione;
import it.uniroma3.siw.model.Scheda;

public interface EsercizioRepository extends CrudRepository<Esercizio, Long> {
	
	public boolean existsByNome(String nome);
	
	public List<Esercizio> findAllByschedeEsercizioIsNotContaining(Scheda scheda);
	
	public List<Esercizio> findAllBySchedeEsercizio(Scheda scheda);
	
	public List<Esercizio> findAllByPrestazioniEsercizio(Prestazione prestazione);
	
	public Esercizio findByNome(String nome);

}
