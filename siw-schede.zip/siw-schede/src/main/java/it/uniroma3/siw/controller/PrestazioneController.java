package it.uniroma3.siw.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import it.uniroma3.siw.model.Credentials;
import it.uniroma3.siw.model.Esercizio;
import it.uniroma3.siw.model.Prestazione;
import it.uniroma3.siw.model.Scheda;
import it.uniroma3.siw.service.CredentialsService;
import it.uniroma3.siw.service.EsercizioService;
import it.uniroma3.siw.service.PrestazioneService;
import it.uniroma3.siw.service.SchedaService;




@Controller
public class PrestazioneController {

	@Autowired PrestazioneService prestazioneService;
	@Autowired SchedaService schedaService;
	@Autowired CredentialsService credenzialiService;
	@Autowired EsercizioService esercizioService;
	
	@GetMapping("/logged/formNewPrestazione/{idScheda}/{idEsercizio}")
	public String formNewPrestazione(@PathVariable("idScheda") Long idScheda,
			@PathVariable("idEsercizio") Long idEsercizio, Model model) {
		model.addAttribute("prestazione", new Prestazione());
		model.addAttribute("scheda", this.schedaService.cercaPerId(idScheda));
		model.addAttribute("esercizio", this.esercizioService.cercaPerId(idEsercizio));
		return "logged/formNewPrestazione.html";
	}

	
	
	@PostMapping("/logged/addPrestazione/{idScheda}/{idEsercizio}")
	public String addPrestazione(@ModelAttribute("prestazione") Prestazione prestazione,
			@PathVariable("idScheda") Long idScheda,
			@PathVariable("idEsercizio") Long idEsercizio, Model model) {
		UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();;
		Credentials credenziali = this.credenzialiService.getCredentials(userDetails.getUsername());
		if (this.prestazioneService.salvaPrestazioneSeEsiste
				(prestazione, this.schedaService.cercaPerId(idScheda),
				this.esercizioService.cercaPerId(idEsercizio), credenziali.getUser())) { 
			model.addAttribute("prestazione", prestazione);
			model.addAttribute("nome", prestazione.getUtente().getCredenziali().getUsername());
			return "prestazione.html";
		} else {
			model.addAttribute("messaggioErrore", "Questa prestazione esiste già");
			return "logged/formNewPrestazione.html"; 
		}
	}
	
	@GetMapping("/prestazione/{id}")
	public String getPrestazione(@PathVariable("id") Long id, Model model) {
		Prestazione prestazione = this.prestazioneService.cercaPerId(id);
		model.addAttribute("prestazione", prestazione);
		model.addAttribute("nome", prestazione.getUtente().getCredenziali().getUsername());
		return "prestazione.html";
	}
	
	@GetMapping("/record/{idEsercizio}")
	public String cercaRecord(@PathVariable("idEsercizio") Long idEsercizio, Model model) {
		Esercizio esercizio = this.esercizioService.cercaPerId(idEsercizio);
		Prestazione prestazione = this.prestazioneService.cercaMaxDaEsercizio(esercizio);
		model.addAttribute("prestazione", prestazione);
		if(prestazione != null)
			model.addAttribute("nome", prestazione.getUtente().getCredenziali().getUsername());
		return "prestazione.html";
	}
	
	@GetMapping("/logged/eliminaPrestazione/{idPrestazione}/{idScheda}/{idEsercizio}")
	public String eliminaPrestazione(@PathVariable("idPrestazione") Long idPrestazione, 
			@PathVariable("idScheda") Long idScheda, 
			@PathVariable("idEsercizio") Long idEsercizio, Model model) {
		this.prestazioneService.cancellaPrestazionePerId(idPrestazione);
		Scheda schedaCorrente = this.schedaService.cercaPerId(idScheda);
		Esercizio esercizioCorrente = this.esercizioService.cercaPerId(idEsercizio);
		model.addAttribute("esercizio", esercizioCorrente);
		model.addAttribute("scheda", schedaCorrente);
		model.addAttribute("prestazioni", this.prestazioneService.cercaPerSchedaEEsercizio(schedaCorrente, esercizioCorrente));
		return "logged/esercizioScheda.html";
	}
}
