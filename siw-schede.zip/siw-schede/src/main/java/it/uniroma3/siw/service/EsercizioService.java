package it.uniroma3.siw.service;

import java.util.LinkedList;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import it.uniroma3.siw.model.Esercizio;
import it.uniroma3.siw.model.Prestazione;
import it.uniroma3.siw.model.Scheda;
import it.uniroma3.siw.repository.EsercizioRepository;

@Service
public class EsercizioService {

		@Autowired private EsercizioRepository esercizioRepository;
		@Autowired private PrestazioneService prestazioneService;
		@Autowired private SchedaService schedaService;
	
		@Transactional
		public void salvaEsercizio(Esercizio esercizio) {
			esercizioRepository.save(esercizio);
		}
		
		@Transactional
		public Esercizio cercaPerId(Long id) {
			return esercizioRepository.findById(id).get();
		}
		
		@Transactional
		public Esercizio cercaPerNome(String nome) {
			return esercizioRepository.findByNome(nome);
		}

		@Transactional
		public List<Esercizio> cercaTutti() {
			return (List<Esercizio>) esercizioRepository.findAll();
		}
		
		@Transactional
		public List<Esercizio> cercaEserciziNoSchedaParametro(Scheda schedaParametro){
			return esercizioRepository.findAllByschedeEsercizioIsNotContaining(schedaParametro);
		}
		
		@Transactional
		public List<Esercizio> cercaEserciziPrestazione(Prestazione prestazione){
			return esercizioRepository.findAllByPrestazioniEsercizio(prestazione);
		}
		
		@Transactional
		public void cancellaEsercizioPerId(Long idEsercizio) {
			Esercizio esercizio = this.cercaPerId(idEsercizio);
			List<Prestazione> prestazioniEsercizio = this.prestazioneService.cercaPrestazioniEsercizioParametro(esercizio);
			for(Prestazione prestazione : prestazioniEsercizio) {
				this.prestazioneService.cancellaPrestazionePerId(prestazione.getId());
			}
			List<Esercizio> esercizi = new LinkedList<Esercizio>();
			esercizi.add(esercizio);
			List<Scheda> schedeEsercizio = this.schedaService.cercaSchedeEsercizioParametro(esercizi);
			for(Scheda scheda : schedeEsercizio) {
				scheda.getEserciziDellaScheda().remove(esercizio);
				this.schedaService.salvaScheda(scheda);
			}
			this.esercizioRepository.delete(esercizio);
		}
}
