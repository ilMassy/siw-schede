package it.uniroma3.siw.repository;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.repository.CrudRepository;

import it.uniroma3.siw.model.Esercizio;
import it.uniroma3.siw.model.Scheda;
import it.uniroma3.siw.model.User;

public interface SchedaRepository extends CrudRepository<Scheda, Long> {
	
	public List<Scheda> findAllByutenteSchedaOrderByDataInizioDesc(User utenteScheda);
	
	public boolean existsByUtenteSchedaAndDataInizio(User utente, LocalDate dataInizio);
	
	public List<Scheda> findAllByEserciziDellaScheda(List<Esercizio> esercizio);
	
}
