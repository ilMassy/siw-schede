package it.uniroma3.siw.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import it.uniroma3.siw.model.Esercizio;
import it.uniroma3.siw.model.Prestazione;
import it.uniroma3.siw.model.Scheda;
import it.uniroma3.siw.model.User;
import it.uniroma3.siw.repository.PrestazioneRepository;


@Service
public class PrestazioneService {

	@Autowired private PrestazioneRepository prestazioneRepository;
	@Autowired private EsercizioService esercizioService;
	
	@Transactional
	public void salvaPrestazione(Prestazione prestazione) {
		prestazioneRepository.save(prestazione);
	}
	
	@Transactional
	public List<Prestazione> cercaPerSchedaEEsercizio(Scheda scheda, Esercizio esercizio) {
		return  prestazioneRepository.findAllBySchedaPrestazioneAndEsercizioPrestazione(scheda, esercizio);
	}
	
	@Transactional
	public boolean salvaPrestazioneSeEsiste(Prestazione prestazione, Scheda scheda, 
			Esercizio esercizio, User utenteCorrente){ 
		if (!prestazioneRepository.existsByNomeAndCommento(prestazione.getNome(), prestazione.getCommento())) {
			prestazione.setEsercizioPrestazione(esercizio);
			prestazione.setSchedaPrestazione(scheda);
			prestazione.setUtente(utenteCorrente);
			this.salvaPrestazione(prestazione);
			esercizio.getPrestazioniEsercizio().add(prestazione);
			esercizioService.salvaEsercizio(esercizio);
			return true;
		}
		return false;
	}
	
	public Prestazione cercaPerId(Long id) {
		return prestazioneRepository.findById(id).get();
	}
	
	public Prestazione cercaMaxDaEsercizio(Esercizio esercizio) {
		return prestazioneRepository.findTopByEsercizioPrestazioneOrderByMisuraDesc(esercizio);
	}
	
	public List<Prestazione> cercaPrestazioniSchedaParametro(Scheda scheda){
		return prestazioneRepository.findAllBySchedaPrestazione(scheda);
	}
	
	public List<Prestazione> cercaPrestazioniEsercizioParametro(Esercizio esercizio){
		return prestazioneRepository.findAllByEsercizioPrestazione(esercizio);
	}
	
	@Transactional
	public void cancellaPrestazionePerId(Long idPrestazione) {
		Prestazione prestazione = this.cercaPerId(idPrestazione);
		List<Esercizio> eserciziPrestazione = esercizioService.cercaEserciziPrestazione(prestazione);
		for(Esercizio esercizio : eserciziPrestazione) {
			esercizio.getPrestazioniEsercizio().remove(prestazione);
			esercizioService.salvaEsercizio(esercizio);
		}
		this.prestazioneRepository.delete(prestazione);
	}
	
}
