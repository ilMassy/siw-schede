package it.uniroma3.siw.controller;

import org.springframework.validation.Validator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;

import it.uniroma3.siw.model.Esercizio;
import it.uniroma3.siw.repository.EsercizioRepository;

@Component
public class EsercizioValidator implements Validator {
  
	@Autowired
  private EsercizioRepository esercizioRepository;

  @Override
  public void validate(Object o, Errors errors) {
    Esercizio esercizio = (Esercizio)o;
    if (esercizio.getNome()!=null && 
    		esercizioRepository.existsByNome(esercizio.getNome())) {
      errors.reject("esercizio.duplicate");
    }
  }
  
  @Override
  public boolean supports(Class<?> aClass) {
    return Esercizio.class.equals(aClass);
  }

}
