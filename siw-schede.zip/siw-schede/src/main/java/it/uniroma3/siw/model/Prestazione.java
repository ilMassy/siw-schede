package it.uniroma3.siw.model;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class Prestazione {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	
	/*può essere la durata in secondi, il numero di ripetizioni effettuate
	o il peso sollevato*/
	private Integer misura; 
	
	private String commento;   //da mettere quando e ne vuole inserire una, può essere blank
	
	private String nome;
	
	@ManyToOne
	private User utente;   //si può vedere chi ha effettuato il record
	
	@ManyToOne
	private Scheda schedaPrestazione;
	
	@ManyToOne
	private Esercizio esercizioPrestazione;
	
	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public Integer getMisura() {
		return misura;
	}

	public void setMisura(Integer misura) {
		this.misura = misura;
	}

	public String getCommento() {
		return commento;
	}

	public void setCommento(String commento) {
		this.commento = commento;
	}
	
	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public User getUtente() {
		return utente;
	}

	public void setUtente(User utenteRecord) {
		this.utente = utenteRecord;
	}

	public Scheda getSchedaPrestazione() {
		return schedaPrestazione;
	}

	public void setSchedaPrestazione(Scheda schedaPrestazione) {
		this.schedaPrestazione = schedaPrestazione;
	}

	public Esercizio getEsercizioPrestazione() {
		return esercizioPrestazione;
	}

	public void setEsercizioPrestazione(Esercizio esercizioPrestazione) {
		this.esercizioPrestazione = esercizioPrestazione;
	}

	@Override
	public boolean equals(Object o) {
		Prestazione that = (Prestazione) o;
		return this.getMisura() == that.getMisura()
				&& this.getNome() == that.getNome()
				&& this.getCommento() == that.getCommento();
	}
	
	@Override
	public int hashCode() {
		return (int) this.getId();
	}

}
