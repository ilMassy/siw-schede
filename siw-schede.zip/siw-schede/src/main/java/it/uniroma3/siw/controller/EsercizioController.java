package it.uniroma3.siw.controller;

import java.io.IOException;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import it.uniroma3.siw.model.Credentials;
import it.uniroma3.siw.model.Esercizio;
import it.uniroma3.siw.service.EsercizioService;

@Controller
public class EsercizioController {
	
	@Autowired EsercizioService esercizioService;
	@Autowired EsercizioValidator esercizioValidator;
	
	@GetMapping("/index")
	public String index() {
		return "index.html";
	}
	
	@GetMapping("/admin/indexAdmin")
	public String indexAdmin() {
		return "admin/indexAdmin.html";
	}

	//l'admin può aggiungere o eliminare esercizi
	@GetMapping("/admin/indexEsercizi")
	public String indexEsercizio() {
		return "admin/indexEsercizi.html";
	}
	
	@GetMapping("/admin/formNewEsercizio")
	public String formNewEsercizio(Model model) {
		model.addAttribute("esercizio", new Esercizio());
		return "admin/formNewEsercizio.html";
	}
	
	@GetMapping("/admin/formCercaEsercizi")
	public String formSearchMovies() {
		return "admin/formCercaEsercizi.html";
	}
	
	@PostMapping("/cercaEsercizio")
	public String searchMovies(Model model, @RequestParam String nome) {
		model.addAttribute("esercizio", this.esercizioService.cercaPerNome(nome));
		return "esercizio.html";
	}
	
	@PostMapping("/admin/esercizio")
	public String newEsercizio(@Valid @ModelAttribute("esercizio") Esercizio esercizio, 
			@RequestParam("file") MultipartFile file, 
            BindingResult bindingResult, Model model) throws IOException {
	    
		this.esercizioValidator.validate(esercizio, bindingResult);
	    if (!bindingResult.hasErrors()) {
	    	
	    	String nomeFile = StringUtils.cleanPath(file.getOriginalFilename());
	    	esercizio.setImmagine(nomeFile);
        	
	    	this.esercizioService.salvaEsercizio(esercizio);
        
        	model.addAttribute("esercizio", esercizio);
        	return "esercizio.html";
	    } else {
	      return "admin/formNewEsercizio.html";
	    }

	}
	
	@GetMapping("/esercizio/{id}")
	public String getEsercizio(@PathVariable("id") Long id, Model model) {
		model.addAttribute("esercizio", this.esercizioService.cercaPerId(id));
		return "esercizio.html";
	}

	@GetMapping("/esercizi")
	public String mostraErcizi(Model model) {
		model.addAttribute("esercizi", this.esercizioService.cercaTutti());
		return "esercizi.html";
	}
	
	@GetMapping("/admin/esercizi")
	public String mostraErciziAdmin(Model model) {
		model.addAttribute("esercizi", this.esercizioService.cercaTutti());
		return "admin/esercizi.html";
	}
	
	@GetMapping("/admin/eliminaEsercizio/{idEsercizio}")
	public String eliminaEsercizio(@PathVariable("idEsercizio") Long idEsercizio, Model model) {
		this.esercizioService.cancellaEsercizioPerId(idEsercizio);
		model.addAttribute("esercizi", this.esercizioService.cercaTutti());
		return "admin/esercizi.html";
	}

}
