package it.uniroma3.siw.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import it.uniroma3.siw.model.Credentials;
import it.uniroma3.siw.model.Esercizio;
import it.uniroma3.siw.model.Scheda;
import it.uniroma3.siw.service.CredentialsService;
import it.uniroma3.siw.service.EsercizioService;
import it.uniroma3.siw.service.PrestazioneService;
import it.uniroma3.siw.service.SchedaService;

import static it.uniroma3.siw.model.Credentials.ADMIN_ROLE;


@Controller
public class SchedaController {

	@Autowired SchedaService schedaService;
	@Autowired EsercizioService esercizioService;
	@Autowired PrestazioneService prestazioneService;
	@Autowired CredentialsService credentialsService;
	
	@GetMapping("/home")
	public String Casa() {
		UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();;
		Credentials credenziali = this.credentialsService.getCredentials(userDetails.getUsername());
		if(credenziali.getRole().equals(ADMIN_ROLE))
			return "admin/indexAdmin.html";
		return "logged/indexLogged.html";
	}
	
	@GetMapping("/logged/indexSchede")
	public String indexSchede() {
		return "logged/indexSchede.html";
	}

	@GetMapping("/logged/formNewScheda")
	public String formNewScheda(Model model) {
		model.addAttribute("scheda", new Scheda());
		return "logged/formNewScheda.html";
	}

	@PostMapping("/logged/scheda")
	public String nuovaScheda(@ModelAttribute("scheda") Scheda scheda, Model model) {
		UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();;
		Credentials credenziali = this.credentialsService.getCredentials(userDetails.getUsername());
		if (this.schedaService.salvaSchedaSeEsiste(scheda, credenziali.getUser())) {
			model.addAttribute("scheda", scheda);
			return "logged/scheda.html";
		}
		else {
			model.addAttribute("messaggioErrore", "Questa scheda non va bene");
			return "logged/formNewScheda.html"; 
		}
	}

	@GetMapping("/logged/scheda/{id}")
	public String getScheda(@PathVariable("id") Long id, Model model) {
		model.addAttribute("scheda", this.schedaService.cercaPerId(id));
		return "logged/scheda.html";
	}

	@GetMapping("/logged/schede")
	public String mostraSchede(Model model) {
		UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();;
		Credentials credenziali = this.credentialsService.getCredentials(userDetails.getUsername());
		model.addAttribute("schede", this.schedaService.cercaTutte(credenziali.getUser()));
		return "logged/schede.html";
	}
	
	@GetMapping("/logged/eserciziScheda/{idScheda}")
	public String mostraEsesciziScheda(@PathVariable("idScheda") Long idScheda, Model model) {
		Scheda schedaCorrente = this.schedaService.cercaPerId(idScheda);
		model.addAttribute("scheda", schedaCorrente);
		model.addAttribute("esercizi", schedaCorrente.getEserciziDellaScheda());
		return "logged/eserciziScheda.html";
	}
	
	@GetMapping("/logged/esercizioScheda/{idScheda}/{idEsercizio}")
	public String mostraEsercizioScheda(@PathVariable("idScheda") Long idScheda,
			@PathVariable("idEsercizio") Long idEsercizio, Model model) {
		Scheda schedaCorrente = this.schedaService.cercaPerId(idScheda);
		Esercizio esercizioCorrente = this.esercizioService.cercaPerId(idEsercizio);
		model.addAttribute("esercizio", esercizioCorrente);
		model.addAttribute("scheda", schedaCorrente);
		model.addAttribute("prestazioni", this.prestazioneService.cercaPerSchedaEEsercizio(schedaCorrente, esercizioCorrente));
		return "logged/esercizioScheda.html";
	}
	
	@GetMapping("/logged/aggiornaScheda/{idScheda}")
	public String aggiornaScheda(@PathVariable("idScheda") Long idScheda, Model model) {
		Scheda scheda = this.schedaService.cercaPerId(idScheda);
		model.addAttribute("scheda", scheda);
		model.addAttribute("eserciziScheda", scheda.getEserciziDellaScheda());
		List<Esercizio> eserciziNonScheda = this.esercizioService.
				cercaEserciziNoSchedaParametro(scheda);
		model.addAttribute("eserciziNonScheda", eserciziNonScheda);
		return "logged/aggiornaEsercizi.html";
	}
	
	@GetMapping("/logged/eliminaEsercizio/{idEsercizio}/{idScheda}")
	public String eliminaEsercizio(@PathVariable("idEsercizio") Long idEsercizio,@PathVariable("idScheda") Long idScheda, Model model) {
		Scheda scheda = this.schedaService.eliminaEsercizioAScheda(idScheda, idEsercizio);

		List<Esercizio> eserciziNonScheda = this.esercizioService.cercaEserciziNoSchedaParametro(scheda);
		model.addAttribute("scheda", scheda);
		model.addAttribute("eserciziScheda", scheda.getEserciziDellaScheda());
		model.addAttribute("eserciziNonScheda", eserciziNonScheda);

		return "logged/aggiornaEsercizi.html";
	}

	@GetMapping("/logged/aggiungiEsercizioAScheda/{idEsercizio}/{idScheda}")
	public String aggiungiEsercizioAScheda(@PathVariable("idEsercizio") Long idEsercizio,@PathVariable("idScheda") Long idScheda, Model model) {
		Scheda scheda = this.schedaService.aggiungiEsercizioAScheda(idScheda, idEsercizio);

		List<Esercizio> eserciziNonScheda = this.esercizioService.cercaEserciziNoSchedaParametro(scheda);
		model.addAttribute("scheda", scheda);
		model.addAttribute("eserciziScheda", scheda.getEserciziDellaScheda());
		model.addAttribute("eserciziNonScheda", eserciziNonScheda);

		return "logged/aggiornaEsercizi.html";
	}
	
	@GetMapping("/logged/eliminaScheda/{idScheda}")
	public String eliminaScheda(@PathVariable("idScheda") Long idScheda, Model model) {
		this.schedaService.cancellaSchedaPerId(idScheda);
		UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();;
		Credentials credenziali = this.credentialsService.getCredentials(userDetails.getUsername());
		model.addAttribute("schede", this.schedaService.cercaTutte(credenziali.getUser()));
		return "logged/schede.html";
	}
	
}
