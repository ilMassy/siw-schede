package it.uniroma3.siw.model;

import java.time.LocalDate;
import java.util.List;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
public class Scheda {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	
	@NotBlank
	@Size(max = 25)
	private String nome;
	
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private LocalDate dataInizio;
	
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private LocalDate dataFine;
	
	@ManyToOne
	private User utenteScheda;
	
	@ManyToMany(mappedBy = "schedeEsercizio")
	public List<Esercizio> eserciziDellaScheda;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public LocalDate getDataInizio() {
		return dataInizio;
	}

	public void setDataInizio(LocalDate dataInizio) {
		this.dataInizio = dataInizio;
	}

	public LocalDate getDataFine() {
		return dataFine;
	}

	public void setDataFine(LocalDate dataFine) {
		this.dataFine = dataFine;
	}

	public List<Esercizio> getEserciziDellaScheda() {
		return eserciziDellaScheda;
	}

	public void setEserciziDellaScheda(List<Esercizio> eserciziDellaScheda) {
		this.eserciziDellaScheda = eserciziDellaScheda;
	}

	public User getUtenteScheda() {
		return utenteScheda;
	}

	public void setUtenteScheda(User utenteScheda) {
		this.utenteScheda = utenteScheda;
	}

	@Override
	public boolean equals(Object o) {
		Scheda that = (Scheda) o;
		return this.getNome() == that.getNome() && this.getDataInizio() == that.getDataInizio()
				&& this.getUtenteScheda().equals(that.getUtenteScheda());
	}
	
	@Override
	public int hashCode() {
		return (int) this.getId();
	}
	
}
