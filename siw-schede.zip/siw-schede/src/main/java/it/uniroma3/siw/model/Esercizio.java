package it.uniroma3.siw.model;

import java.time.LocalTime;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Positive;

import org.springframework.format.annotation.DateTimeFormat;


@Entity
public class Esercizio {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	
	@NotBlank
	private String descrizione; 
	
	@Column(length = 500)
	private String immagine;
	
	@NotBlank
	private String nome;
	
	@NotBlank
	private String obiettivo;
	
	@ManyToMany
	public List<Scheda> schedeEsercizio;
	
	@OneToMany
	private List<Prestazione> prestazioniEsercizio;
	
	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getDescrizione() {
		return descrizione;
	}

	public void setDescrizione(String descrizione) {
		this.descrizione = descrizione;
	}

	public List<Prestazione> getPrestazioniEsercizio() {
		return prestazioniEsercizio;
	}

	public void setPrestazioniEsercizio(List<Prestazione> prestazioniEsercizio) {
		this.prestazioniEsercizio = prestazioniEsercizio;
	}

	public List<Scheda> getSchedeEsercizio() {
		return schedeEsercizio;
	}

	public void setSchedeEsercizio(List<Scheda> schedeEsercizio) {
		this.schedeEsercizio = schedeEsercizio;
	}

	public String getImmagine() {
		return immagine;
	}

	public void setImmagine(String immagine) {
		this.immagine = immagine;
	}
	
	public String getObiettivo() {
		return obiettivo;
	}

	public void setObiettivo(String obiettivo) {
		this.obiettivo = obiettivo;
	}

	@Override
	public boolean equals(Object o) {
		Esercizio that = (Esercizio) o;
		return this.getNome() == that.getNome();
	}
	
	@Override
	public int hashCode() {
		return (int) this.getId();
	}
	
}
