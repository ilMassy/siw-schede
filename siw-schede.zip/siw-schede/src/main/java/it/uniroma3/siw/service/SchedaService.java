package it.uniroma3.siw.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import it.uniroma3.siw.model.Esercizio;
import it.uniroma3.siw.model.Prestazione;
import it.uniroma3.siw.model.Scheda;
import it.uniroma3.siw.model.User;
import it.uniroma3.siw.repository.EsercizioRepository;
import it.uniroma3.siw.repository.PrestazioneRepository;
import it.uniroma3.siw.repository.SchedaRepository;
import it.uniroma3.siw.repository.UserRepository;

@Service
public class SchedaService {
	
	@Autowired private SchedaRepository schedaRepository;
	@Autowired private UserRepository utenteRepository;
	@Autowired private EsercizioRepository esercizioRepository;
	@Autowired private PrestazioneService prestazioneService;
	
	@Transactional
	public void salvaScheda(Scheda scheda) {
		schedaRepository.save(scheda);
	}
	
	@Transactional
	public boolean salvaSchedaSeEsiste(Scheda scheda, User utenteCorrente){ 
		if (!schedaRepository.existsByUtenteSchedaAndDataInizio(scheda.getUtenteScheda(), scheda.getDataInizio())
				&& scheda.getDataInizio().isBefore(scheda.getDataFine())) {
			utenteRepository.save(utenteCorrente);
			scheda.setUtenteScheda(utenteCorrente);
			this.salvaScheda(scheda); 
			return true;
		}
		return false;
	}
		
	@Transactional
	public Scheda cercaPerId(Long id) {
		return schedaRepository.findById(id).get();
	}
	
	@Transactional
	public List<Scheda> cercaTutte(User utente) {
		return schedaRepository.findAllByutenteSchedaOrderByDataInizioDesc(utente);
	}
	
	@Transactional
	public List<Scheda> cercaSchedeEsercizioParametro(List<Esercizio> esercizi) {
		return schedaRepository.findAllByEserciziDellaScheda(esercizi);
	}
	
	@Transactional
	public Scheda eliminaEsercizioAScheda(Long idScheda, Long idEsercizio) {
		Scheda scheda = this.schedaRepository.findById(idScheda).get();
		Esercizio esercizio = this.esercizioRepository.findById(idEsercizio).get();

		List<Esercizio> eserciziScheda = scheda.getEserciziDellaScheda();
		eserciziScheda.remove(esercizio);
		esercizio.getSchedeEsercizio().remove(scheda);
		scheda.setEserciziDellaScheda(eserciziScheda);

		this.schedaRepository.save(scheda);
		
		return scheda;
	}
	
	@Transactional
	public Scheda aggiungiEsercizioAScheda(Long idScheda, Long idEsercizio) {
		Scheda scheda = this.schedaRepository.findById(idScheda).get();
		Esercizio esercizio = this.esercizioRepository.findById(idEsercizio).get();

		List<Esercizio> eserciziScheda = scheda.getEserciziDellaScheda();
		eserciziScheda.add(esercizio);
		List<Scheda> schedeEsercizio = esercizio.getSchedeEsercizio();
		if(!schedeEsercizio.contains(scheda))
			schedeEsercizio.add(scheda);
		scheda.setEserciziDellaScheda(eserciziScheda);

		this.schedaRepository.save(scheda);
		
		return scheda;
	}
	
	@Transactional
	public void cancellaSchedaPerId(Long idScheda) {
		Scheda scheda = this.cercaPerId(idScheda);
		List<Esercizio> eserciziScheda = this.esercizioRepository.findAllBySchedeEsercizio(scheda);
		for(Esercizio esercizio : eserciziScheda) {
			esercizio.getSchedeEsercizio().remove(scheda);
			this.esercizioRepository.save(esercizio);
		}
		List<Prestazione> prestazioniScheda = this.prestazioneService.cercaPrestazioniSchedaParametro(scheda);
		for(Prestazione prestazione : prestazioniScheda) {
			this.prestazioneService.cancellaPrestazionePerId(prestazione.getId());
		}
		this.schedaRepository.delete(scheda);
	}
	
}
