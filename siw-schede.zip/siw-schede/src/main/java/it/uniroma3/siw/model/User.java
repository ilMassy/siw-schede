package it.uniroma3.siw.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.Email;

@Entity
@Table(name = "users") // cambiamo nome perchè in postgres user e' una parola riservata
public class User {
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

	private String nome;
	private String cognome;
	
	@Email
	private String email;
	
	@OneToOne(cascade = CascadeType.ALL)
	private Credentials credenziali;
	
    public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}
	
	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getCognome() {
		return cognome;
	}

	public void setCognome(String cognome) {
		this.cognome = cognome;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Credentials getCredenziali() {
		return credenziali;
	}

	public void setCredenziali(Credentials credenziali) {
		this.credenziali = credenziali;
	}

	
	@Override
	public boolean equals(Object o) {
		User that = (User) o;
		return this.getCredenziali().getUsername() == that.getCredenziali().getUsername()
				&& this.getCredenziali().getPassword() == that.getCredenziali().getPassword();
	}
	
}