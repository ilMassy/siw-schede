package it.uniroma3.siw.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import it.uniroma3.siw.model.Esercizio;
import it.uniroma3.siw.model.Prestazione;
import it.uniroma3.siw.model.Scheda;

public interface PrestazioneRepository extends CrudRepository<Prestazione, Long> {

	public List<Prestazione> findAllBySchedaPrestazioneAndEsercizioPrestazione(
			Scheda schedaPrestazione, Esercizio esercizioPrestazione);

	public boolean existsByNomeAndCommento(String nome, String commento);
	
	public Prestazione findTopByEsercizioPrestazioneOrderByMisuraDesc(Esercizio esercizioPrestazione);
	
	public List<Prestazione> findAllBySchedaPrestazione(Scheda scheda);
	
	public List<Prestazione> findAllByEsercizioPrestazione(Esercizio esercizio);
}
