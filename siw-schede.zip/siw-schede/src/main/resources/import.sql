insert into esercizio values(nextval('hibernate_sequence'), 'Deprimi le scapole, addome contratto, gambe tese', 'front-lever.jpeg', 'Front lever', 'Effettuare isometria con maggior secondaggio');
insert into esercizio values(nextval('hibernate_sequence'), '...', 'military-press.jpeg', 'Military press', 'Sollevare il maggior carico possibile');
insert into esercizio values(nextval('hibernate_sequence'), '...', 'piegamenti-sulle-braccia.jpg', 'Piegamenti sulle braccia', 'Effettuare il maggior numero di ripetizioni possibile');

